-- drop database if exists productora_musical; 
-- create database if not exists productora_musical;
-- USE productora_musical;

-- Tabla de bandas
create table bandas (
    id_banda int auto_increment primary key,
    nombre varchar(150) not null,
    genero enum('Rock','R&B','Metal','Folcklore','Clasica','Hip-Hop','Electronica','LatinoAmericano') not null,
    contacto varchar(100),
    cantidad_musicos int not null,
    observaciones varchar(150)
);
-- Lugares específicos donde se hacen los eventos
create table lugares (
    id_lugar int auto_increment primary key,
    nombre_lugar varchar(100) not null,
    contacto varchar(150) not null,
    direccion varchar(100) not null,
    tipo_lugar enum('Bar', 'Centro Cultural', 'Festival-AireLibre', 'Micro Estadio','Teatro','Club Nocturno') not null,
    capacidad int not null,
    observaciones varchar(150)
);

-- Eventos organizados por la productora
create table eventos (
    id_evento int auto_increment primary key,
    nombre varchar(100) not null,
    fecha date not null,
    horario time(6) not null,
    id_lugar int not null,
    descripcion varchar(1500),
    foreign key (id_lugar) references lugares(id_lugar)
);
-- Necesidades específicas segun Banda(genero) y tipo de lugar

create table necesidades (
    id_necesidad int auto_increment primary key,
    id_banda int not null,
    tipo_lugar enum('Bar', 'Centro Cultural', 'Festival-AireLibre', 'Micro Estadio','Teatro','Club Nocturno') not null,
    descripcion varchar(1500),
    foreign key (id_banda) references bandas(id_banda),
    unique (id_banda, tipo_lugar) -- Para q no se repitan las necesidades para una misma banda y tipo de lugar
);
-- Relación de bandas que participan en eventos
create table bandas_eventos (
    id_banda int,
    id_evento int,
	id_necesidad int,
    primary key (id_banda, id_evento),
    foreign key (id_banda) references bandas(id_banda),
    foreign key (id_evento) references eventos(id_evento),
    foreign key (id_necesidad) references necesidades(id_necesidad)
);
