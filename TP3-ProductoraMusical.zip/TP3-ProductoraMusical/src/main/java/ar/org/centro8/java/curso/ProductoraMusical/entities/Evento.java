package ar.org.centro8.java.curso.ProductoraMusical.entities;


import java.sql.Time;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Evento {

    private int idEvento;
    private String nombre;
    private LocalDate fecha;
    private Time horario;
    private int idLugar;
    private String descripcion;

    

}
