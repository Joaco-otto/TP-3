package ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Lugar;

public interface I_LugarRepository {

    void create(Lugar lugar) throws SQLException;
    Lugar findById(int idLugar) throws SQLException;
    List<Lugar> findAll() throws SQLException;
    int update (Lugar lugar) throws SQLException;
    int delete(Lugar idLugar) throws SQLException; 
    List<Lugar> findByCapacidad(int capacidad) throws SQLException;
    List<Lugar> findByNombreLugar(String nombreLugar) throws SQLException;

}
