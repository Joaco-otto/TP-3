package ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.ProductoraMusical.entities.BandaEvento;

public interface I_BandaEventoRepository {

    void create(BandaEvento bandaEvento) throws SQLException;

    BandaEvento findById(int idBanda, int idEvento) throws SQLException;

    List<BandaEvento> findAll() throws SQLException;

    int update(BandaEvento bandaEvento) throws SQLException;

    int delete(int idBanda, int idEvento) throws SQLException;

    List<BandaEvento> findByBanda(int idBanda) throws SQLException;

}
