package ar.org.centro8.java.curso.ProductoraMusical.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;
import ar.org.centro8.java.curso.ProductoraMusical.entities.Lugar;
import ar.org.centro8.java.curso.ProductoraMusical.enums.TipoLugar;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_LugarRepository;
@Repository
public class LugarRepository implements I_LugarRepository {

    private final DataSource dataSource;
        
     private static final String SQL_CREATE = 
    "INSERT INTO lugares ( nombre_lugar, contacto, direccion, tipo_lugar, capacidad,observaciones) values (?,?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM lugares WHERE id_Lugar=?";

    private static final String SQL_FIND_ALL =
        "SELECT * FROM lugares";

    private static final String SQL_UPDATE = 
        "UPDATE lugares SET nombre_lugar=?, contacto=?, direccion=?, tipo_lugar=?, capacidad=? , observaciones=? WHERE id_Lugar=?";

    private static final String SQL_DELETE = 
    
    "DELETE FROM lugares WHERE id_lugar=?";

    private static final String SQL_FIND_BY_CAPACIDAD =
    
    "SELECT id_lugar, nombre_lugar, contacto, direccion, tipo_lugar, capacidad WHERE capacidad= ?";

    private static final String SQL_FIND_BY_NOMBRE_LUGAR =
    
    "SELECT * FROM lugares WHERE nombre_lugar=?";
     
    public LugarRepository(DataSource dataSource){
        this.dataSource = dataSource; 

   }

    @Override
    public void create(Lugar lugar) throws SQLException {

        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)){
                    ps.setString(1, lugar.getNombreLugar());      
                    ps.setString(2, lugar.getContacto());
                    ps.setString(3, lugar.getDireccion());
                    ps.setString(4, lugar.getTipoLugar().getLabel());
                    ps.setInt(5, lugar.getCapacidad()); 
                    ps.setString(6, lugar.getObservaciones());                   
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if(keys.next()){
                            lugar.setIdLugar(keys.getInt(1));  
                        }
                    }
            }        
    }

    @Override
    public Lugar findById(int idLugar) throws SQLException {

         try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)){
                 ps.setInt(1, idLugar);
                    try (ResultSet rs = ps.executeQuery()) {
                        if(rs.next()){
                            return mapRow(rs);
                        }                        
                    }            
            }
            return null;
    }

    @Override
    public List<Lugar> findAll() throws SQLException {
        List<Lugar> lista = new ArrayList<>();
        try(Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL)) {
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        lista.add(mapRow(rs));
                    }            
        } 
        return lista; 

    }

    @Override
    public int update(Lugar lugar) throws SQLException {
     try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)){
            ps.setString(1, lugar.getNombreLugar());
            ps.setString(2, lugar.getContacto());
            ps.setString(3, lugar.getDireccion());
            ps.setString(4, lugar.getTipoLugar().getLabel());
            ps.setInt(5, lugar.getCapacidad());
            ps.setString(6, lugar.getObservaciones());
            ps.setInt(7, lugar.getIdLugar());
            int filasAfectadas = ps.executeUpdate();
                    return filasAfectadas;

                }
    }

    @Override
    public int delete(Lugar idLugar) throws SQLException {


        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)){
                    ps.setInt(1, idLugar.getIdLugar());
                    int filasAfectadas = ps.executeUpdate();
                    return filasAfectadas; 
                }
    
    }


    @Override
    public List<Lugar> findByCapacidad(int capacidad) throws SQLException {
        String sql = "SELECT id_lugar, nombre_lugar, contacto, direccion, tipo_lugar, capacidad FROM lugares WHERE capacidad = ?";
        List<Lugar> bandas = new ArrayList<>();
    try (Connection conn = dataSource.getConnection();
         PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_CAPACIDAD)) {

        ps.setInt(1, capacidad);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                bandas.add(mapRow(rs));
            }
        }
    }
    return bandas;
    }

    @Override
    public List<Lugar> findByNombreLugar(String nombreLugar) throws SQLException {
       List<Lugar> bandas = new ArrayList<>();
    try (Connection conn = dataSource.getConnection();
         PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE_LUGAR)) {

        ps.setString(1, nombreLugar);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                bandas.add(mapRow(rs));
            }
        }
    }
    return bandas;


    }

        private Lugar mapRow(ResultSet rs) throws SQLException {
      
        Lugar lugar = new Lugar();

        lugar.setIdLugar(rs.getInt("id_Lugar"));
        lugar.setNombreLugar(rs.getString("nombre_lugar"));
        lugar.setContacto(rs.getString("contacto"));
        lugar.setDireccion(rs.getString("direccion"));
        lugar.setTipoLugar(TipoLugar.fromLabel(rs.getString("tipo_lugar"))); 
        lugar.setCapacidad(rs.getInt("capacidad"));
       return lugar;
        
      }
     
}