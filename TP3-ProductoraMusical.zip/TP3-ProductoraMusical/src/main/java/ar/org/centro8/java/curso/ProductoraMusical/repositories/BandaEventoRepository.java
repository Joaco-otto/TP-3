package ar.org.centro8.java.curso.ProductoraMusical.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.ProductoraMusical.entities.BandaEvento;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_BandaEventoRepository;

@Repository

public class BandaEventoRepository implements I_BandaEventoRepository{
   private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO bandas_eventos (id_banda, id_evento, id_necesidad) VALUES (?, ?, ?)";

    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM bandas_eventos WHERE id_banda = ? AND id_evento = ? AND id_necesidad = ?";

    private static final String SQL_FIND_ALL =
        "SELECT * FROM bandas_eventos";

    private static final String SQL_UPDATE =
        "UPDATE bandas_eventos SET id_necesidad = ? WHERE id_banda = ? AND id_evento = ?";

    private static final String SQL_DELETE =
        "DELETE FROM bandas_eventos WHERE id_banda = ? AND id_evento = ? AND id_necesidad = ?";
    
        private static final String SQL_FIND_BY_BANDA =
    "SELECT * FROM bandas_eventos WHERE id_banda = ?";

    public BandaEventoRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(BandaEvento bandaevento) throws SQLException {
try (Connection conn = dataSource.getConnection();
               PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)){
            ps.setInt(1, bandaevento.getIdBanda());
            ps.setInt(2, bandaevento.getIdEvento());
            ps.setInt(3, bandaevento.getIdNecesidad());
            ps.executeUpdate();
        }
    }
    

    @Override
    public BandaEvento findById(int idBanda, int idEvento, int idNecesidad) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idBanda);
            ps.setInt(2, idEvento);
            ps.setInt(3, idNecesidad);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;


    }

   

    @Override
    public List<BandaEvento> findAll() throws SQLException {
        List<BandaEvento> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }
    

    @Override
    public int update(BandaEvento bandaevento) throws SQLException {
       try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, bandaevento.getIdNecesidad());
            ps.setInt(2, bandaevento.getIdBanda());
            ps.setInt(3, bandaevento.getIdEvento());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int idBanda, int idEvento, int idNecesidad) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idBanda);
            ps.setInt(2, idEvento);
            ps.setInt(3, idNecesidad);
            return ps.executeUpdate();
        }

    }
    @Override
         public List<BandaEvento> findByBanda(int idBanda) throws SQLException {
        List<BandaEvento> list = new ArrayList<>();
         try (Connection conn = dataSource.getConnection();
         PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_BANDA)) {
        ps.setInt(1, idBanda);
        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
    }
    return list;
}

 private BandaEvento mapRow(ResultSet rs) throws SQLException {
        return new BandaEvento(
            rs.getInt("id_banda"),
            rs.getInt("id_evento"),
            rs.getInt("id_necesidad")
        );
    }
       
    

}
