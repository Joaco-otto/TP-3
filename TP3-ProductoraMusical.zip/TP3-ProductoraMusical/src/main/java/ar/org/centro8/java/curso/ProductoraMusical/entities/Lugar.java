package ar.org.centro8.java.curso.ProductoraMusical.entities;

import ar.org.centro8.java.curso.ProductoraMusical.enums.TipoLugar;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Lugar {
    private int idLugar;
    private String nombreLugar;
    private String contacto;
    private String direccion;
    private TipoLugar tipoLugar;
    private int capacidad;
    private String observaciones;


}
