package ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Necesidad;

public interface I_NecesidadRepository {

    /*
     * Solamente se usa estos metodos para Necesidad debido a que nuestra base de datos
     * esta disenado con UNIQUE en los campos "id_banda" y "tipo_lugar"
     * lo que cada banda solo puede tener una necesidad específica por cada tipo de lugar
     * debido a esto no se puede crear o asignar una nueva necesidad a una banda para el 
     * mismo tipo de lugar.
     */

    Necesidad findById(int idNecesidad) throws SQLException;

    List<Necesidad> findAll() throws SQLException;

    List<Necesidad> findByIdBanda(int idBanda) throws SQLException;

}
