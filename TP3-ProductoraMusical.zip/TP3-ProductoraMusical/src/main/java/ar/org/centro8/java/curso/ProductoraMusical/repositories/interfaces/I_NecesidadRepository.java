package ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Necesidad;

public interface I_NecesidadRepository {
    
    void create(Necesidad necesidad) throws SQLException;
    Necesidad findById(int idNecesidad) throws SQLException;
    List<Necesidad> findAll() throws SQLException;
    int update (Necesidad necesidad) throws SQLException;
    int delete(Necesidad idNecesidad) throws SQLException; 
    List<Necesidad> findByIdBanda(int idBanda) throws SQLException;
    

}
