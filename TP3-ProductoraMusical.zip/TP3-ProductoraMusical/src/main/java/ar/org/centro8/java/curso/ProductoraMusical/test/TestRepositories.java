package ar.org.centro8.java.curso.ProductoraMusical.test;

import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Banda;
import ar.org.centro8.java.curso.ProductoraMusical.entities.BandaEvento;
import ar.org.centro8.java.curso.ProductoraMusical.entities.Evento;
import ar.org.centro8.java.curso.ProductoraMusical.entities.Lugar;
import ar.org.centro8.java.curso.ProductoraMusical.entities.Necesidad;
import ar.org.centro8.java.curso.ProductoraMusical.enums.Genero;
import ar.org.centro8.java.curso.ProductoraMusical.enums.TipoLugar;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.BandaRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.EventoRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.LugarRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.NecesidadRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_BandaEventoRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_BandaRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_EventoRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_LugarRepository;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_NecesidadRepository;

@SpringBootApplication(scanBasePackages = "ar.org.centro8.java.curso.ProductoraMusical")
public class TestRepositories {

    public static void main(String[] args) {
        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args)) {

            I_BandaRepository bandaRepository = context.getBean(BandaRepository.class);
            I_EventoRepository eventoRepository = context.getBean(EventoRepository.class);
            I_LugarRepository lugarRepository = context.getBean(LugarRepository.class);
            I_NecesidadRepository necesidadRepository = context.getBean(NecesidadRepository.class);
            I_BandaEventoRepository repo = context.getBean(I_BandaEventoRepository.class);

            System.out.println(" 🤘 PRODUCTORA MUSICAL 🤘 ");
            System.out.println(" 🎶 BIENVENIDOS 🎶 ");

            // TEST: BANDAS
            System.out.println(" TEST REPOSITORIO DE BANDAS ");

            // TEST 1 : CREAR UNA NUEVA BANDA
            System.out.println(" Test 1: CREANDO UNA BANDA  ");

            System.out.println("    ══════════════════════════════");
            Banda nuevaBanda = new Banda(0,
                    "Divididos",
                    Genero.Rock,
                    "divididos@rock.com",
                    4,
                    "Power trío con historia");
            try {
                bandaRepository.create(nuevaBanda);
                if (nuevaBanda.getIdBanda() > 0) {
                    System.out.println("*.- Banda creada correctamente con ID " + nuevaBanda.getIdBanda());
                    System.out.println(nuevaBanda);
                } else {
                    System.err.println("*.-  - ¡¡ No se pudo crear la banda !!");
                }
            } catch (Exception e) {
                System.err.println("Error al crear banda: " + e.getMessage());
            }

            // ! TEST 2 - Buscar por ID
            System.out.println("\n>>> Test 2: BUSCANDO BANDA POR ID <<<");
            System.out.println("    ════════════════════════════════");
            try {
                Banda bandaEncontrada = bandaRepository.findById(nuevaBanda.getIdBanda());
                if (bandaEncontrada != null) {
                    System.out.println("*.- Banda encontrada: " + bandaEncontrada);
                } else {
                    System.err.println(
                            "*.- ¡¡ ERROR - No se encontró la banda con ID " + nuevaBanda.getIdBanda() + " !!");
                }
            } catch (Exception e) {
                System.err.println("Error al buscar banda: " + e.getMessage());
            }

            // ! TEST 3 - Buscar por ID inexistente
            System.out.println("\n>>> Test 3: BUSCANDO BANDA CON ID 999 (inexistente) <<<");
            System.out.println("    ═══════════════════════════════════════════════");
            try {
                Banda bandaInexistente = bandaRepository.findById(999);
                if (bandaInexistente != null) {
                    System.out.println("*.- Banda encontrada: " + bandaInexistente);
                } else {
                    System.err.println("*.- ¡¡ ERROR - No se encontró banda con ID 999 !!");
                }
            } catch (Exception e) {
                System.err.println("Error al buscar ID inexistente: " + e.getMessage());
            }

            // ! TEST 4 - Actualizar banda
            System.out.println("\n>>> Test 4: ACTUALIZANDO BANDA <<<");
            System.out.println("    ════════════════════════════════");
            try {
                nuevaBanda.setNombre("Divididos (Actualizado)");
                int filas = bandaRepository.update(nuevaBanda);
                if (filas == 1) {
                    System.out.println("*.- Banda actualizada correctamente");
                    System.out.println("*.- Verificando: " + bandaRepository.findById(nuevaBanda.getIdBanda()));
                } else {
                    System.err.println("*.- ¡¡ ERROR - No se pudo actualizar la banda !!");
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar banda: " + e.getMessage());
            }

            // ! TEST 5 - Buscar por género
            System.out.println("\n>>> Test 5: BUSCAR BANDAS POR GÉNERO ROCK <<<");
            System.out.println("    ════════════════════════════════════════");
            try {
                List<Banda> bandasRock = bandaRepository.findByGenero(Genero.Rock);
                bandasRock.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al buscar por género: " + e.getMessage());
            }

            // ! TEST 6 - Buscar por cantidad de músicos
            System.out.println("\n>>> Test 6: BUSCAR BANDAS CON 4 MÚSICOS <<<");
            System.out.println("    ════════════════════════════════════════");
            try {
                List<Banda> bandasCon4 = bandaRepository.findByCantidadMusicos(4);
                bandasCon4.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al buscar por cantidad de músicos: " + e.getMessage());
            }

            // ! TEST 7 - Listar todas las bandas
            System.out.println("\n>>> Test 7: LISTANDO TODAS LAS BANDAS <<<");
            System.out.println("    ════════════════════════════════════════");
            try {
                List<Banda> todas = bandaRepository.findAll();
                todas.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al listar bandas: " + e.getMessage());
            }

            // ! TEST 8 - Eliminar banda
            System.out.println("\n>>> Test 8: ELIMINANDO BANDA <<<");
            System.out.println("    ════════════════════════════════");
            try {
                int filas = bandaRepository.delete(nuevaBanda.getIdBanda());
                if (filas == 1) {
                    System.out.println("*.- Banda eliminada correctamente.");
                    System.out.println(" Verificación post-delete: " + bandaRepository.findById(nuevaBanda.getIdBanda()));
                } else {
                    System.err.println("*.- ¡¡ ERROR - No se pudo eliminar la banda !!");
                }
            } catch (Exception e) {
                System.err.println("Error al eliminar banda: " + e.getMessage());
            }

            System.out.println("\n<<< PRUEBAS COMPLETADAS PARA BANDA >>>");
            System.out.println("═════════════════════════════════════\n");

            // TEST EVENTOS
            System.out.println(" TEST REPOSITORIO DE EVENTOS ");

            // TEST 1: Crear un nuevo evento
            System.out.println("\n>>> Test 1: CREANDO EVENTO <<<");
            Evento nuevoEvento = new Evento(0, "Festival Primavera",
                    (LocalDate.of(2025, 9, 21)),
                    Time.valueOf(LocalTime.of(18, 30)), 1,
                    "Festival con varias bandas al aire libre");

            try {
                eventoRepository.create(nuevoEvento);
                if (nuevoEvento.getIdEvento() > 0) {
                    System.out.println("*.- Evento creado con ID: " + nuevoEvento.getIdEvento());
                    System.out.println(nuevoEvento);
                } else {
                    System.err.println(" No se pudo crear el evento!");
                }
            } catch (Exception e) {
                System.err.println("Error al crear evento: " + e.getMessage());
            }

            // TEST 2: Buscar evento por ID
            System.out.println("\n>>> Test 2: BUSCAR EVENTO POR ID <<<");
            try {
                Evento encontrado = eventoRepository.findById(nuevoEvento.getIdEvento());
                if (encontrado != null) {
                    System.out.println("*.- Evento encontrado: " + encontrado);
                } else {
                    System.err.println("*.- ¡Evento no encontrado!");
                }
            } catch (Exception e) {
                System.err.println("Error al buscar evento: " + e.getMessage());
            }

            // TEST 3: Actualizar evento
            System.out.println("\n>>> Test 3: ACTUALIZAR EVENTO <<<");
            try {
                nuevoEvento.setNombre("Festival Primavera - Edición Actualizada");
                nuevoEvento.setDescripcion("Evento actualizado con nueva descripción");
                int filas = eventoRepository.update(nuevoEvento);
                if (filas == 1) {
                    System.out.println("*.- Evento actualizado correctamente");
                    System.out.println("*.- Verificación: " + eventoRepository.findById(nuevoEvento.getIdEvento()));
                } else {
                    System.err.println("*.- ¡No se pudo actualizar el evento!");
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar evento: " + e.getMessage());
            }

            // TEST 4: Buscar por fecha
            System.out.println("\n>>> Test 4: BUSCAR EVENTOS POR FECHA <<<");
            try {
                List<Evento> eventosFecha = eventoRepository.findByFecha(nuevoEvento.getFecha());
                eventosFecha.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al buscar por fecha: " + e.getMessage());
            }

            // TEST 5: Buscar por nombre
            System.out.println("\n>>> Test 5: BUSCAR EVENTOS POR NOMBRE <<<");
            try {
                List<Evento> eventosNombre = eventoRepository.findByNombre("Festival Primavera - Edición Actualizada");
                eventosNombre.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al buscar por nombre: " + e.getMessage());
            }

            // TEST 6: Listar todos los eventos
            System.out.println("\n>>> Test 6: LISTAR TODOS LOS EVENTOS <<<");
            try {
                List<Evento> todos = eventoRepository.findAll();
                todos.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al listar eventos: " + e.getMessage());
            }

            // TEST 7: Eliminar evento
            System.out.println("\n>>> Test 7: ELIMINAR EVENTO <<<");
            try {
                int filas = eventoRepository.delete(nuevoEvento.getIdEvento());
                if (filas == 1) {
                    System.out.println("*.- Evento eliminado correctamente");
                    Evento verificacion = eventoRepository.findById(nuevoEvento.getIdEvento());
                    System.out.println("*.- Verificación post-delete: " + verificacion);
                } else {
                    System.err.println("*.- ¡No se pudo eliminar el evento!");
                }
            } catch (Exception e) {
                System.err.println("Error al eliminar evento: " + e.getMessage());
            }

            System.out.println("FIN DE PRUEBAS PARA EVENTO ");

            // TEST LUGARES
            System.out.println(" TEST REPOSITORIO DE LUGARES ");

            // TEST 1: Crear un nuevo lugar
            System.out.println("\n>>> Test 1: CREAR NUEVO LUGAR <<<");
            Lugar nuevoLugar = new Lugar(
                    0,
                    "Puna Park",
                    "contacto@lunapark.com",
                    "Av. Corrientes 1234, CABA",
                    TipoLugar.MicroEstadio,
                    8000,
                    "Histórico estadio cubierto");

            try {
                lugarRepository.create(nuevoLugar);
                if (nuevoLugar.getIdLugar() > 0) {
                    System.out.println("*.- Lugar creado con ID: " + nuevoLugar.getIdLugar());
                    System.out.println(nuevoLugar);
                } else {
                    System.err.println(" No se pudo crear el lugar!");
                }
            } catch (Exception e) {
                System.err.println("Error al crear lugar: " + e.getMessage());
            }

            System.out.println("\n>>> TEST 2: BUSCAR LUGAR POR ID <<<");
            System.out.println("═════════════════════════════════════");
            try {
                Lugar lugarEncontrado = lugarRepository.findById(nuevoLugar.getIdLugar());
                if (lugarEncontrado != null) {
                    System.out.println("*.- Lugar encontrado: " + lugarEncontrado);
                } else {
                    System.err.println(
                            "*.- ¡¡ ERROR - No se encontró el lugar con ID " + nuevoLugar.getIdLugar() + " !!");
                }
            } catch (Exception e) {
                System.err.println("Error al buscar lugar por ID: " + e.getMessage());
            }

            // TEST 3: Actualizar lugar
            System.out.println("\n>>> Test 3: ACTUALIZAR LUGAR <<<");
            try {
                nuevoLugar.setNombreLugar("Luna Park (Actualizado)");
                nuevoLugar.setCapacidad(8500);
                int filas = lugarRepository.update(nuevoLugar);
                if (filas == 1) {
                    System.out.println("*.- Lugar actualizado correctamente");
                    System.out.println("*.- Verificación: " + lugarRepository.findById(nuevoLugar.getIdLugar()));
                } else {
                    System.err.println("*.- ¡No se pudo actualizar el lugar!");
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar lugar: " + e.getMessage());
            }

            // TEST 4: Buscar por capacidad
            System.out.println("\n>>> Test 4: BUSCAR LUGARES POR CAPACIDAD = 300 <<<");
            try {
                List<Lugar> lugaresCapacidad = lugarRepository.findByCapacidad(300);
                lugaresCapacidad.forEach(System.out::println);
            } catch (SQLException e) {
                System.err.println("Error al buscar por capacidad: " + e.getMessage());
            }

            // TEST 5: Buscar por nombre del lugar
            System.out.println("\n>>> Test 5: BUSCAR LUGAR POR NOMBRE (La Tangente) <<<");
            try {
                List<Lugar> lugaresPorNombre = lugarRepository.findByNombreLugar("La Tangente");
                lugaresPorNombre.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al buscar por nombre: " + e.getMessage());
            }

            // TEST 6: Listar todos los lugares
            System.out.println("\n>>> Test 6: LISTAR TODOS LOS LUGARES <<<");
            try {
                List<Lugar> todos = lugarRepository.findAll();
                todos.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al listar lugares: " + e.getMessage());
            }

            // TEST 7: Eliminar Lugar
            System.out.println("\n>>> TEST 7: ELIMINAR LUGAR <<<");
            System.out.println("════════════════════════════════");
            try {
                int filas = lugarRepository.delete(nuevoLugar.getIdLugar());
                if (filas == 1) {
                    System.out.println("*.- Lugar eliminado correctamente.");
                    System.out.println(
                            "*.- Verificación post-delete: " + lugarRepository.findById(nuevoLugar.getIdLugar()));
                } else {
                    System.err.println("*.- ¡¡ ERROR - No se pudo eliminar el lugar !!");
                }
            } catch (Exception e) {
                System.err.println("Error al eliminar lugar: " + e.getMessage());
            }

            System.out.println(" FIN DE PRUEBAS PARA LUGAR ");

            // TEST NECESIDADES
            System.out.println(" TEST REPOSITORIO DE NECESIDADES ");

            // TEST 1: Buscar por ID
            System.out.println("\n>>> Test 1: BUSCAR NECESIDAD POR ID <<<");
            try {
                Necesidad encontrada = necesidadRepository.findById(5);
                if (encontrada != null) {
                    System.out.println("*.- Necesidad encontrada: " + encontrada);
                } else {
                    System.err.println("*.- ¡Necesidad no encontrada!");
                }
            } catch (Exception e) {
                System.err.println("Error al buscar por ID: " + e.getMessage());
            }

            // TEST 2: Buscar por idBanda
            System.out.println("\n>>> Test 2: BUSCAR NECESIDADES POR ID DE BANDA  <<<");
            try {
                List<Necesidad> necesidadesBanda = necesidadRepository.findByIdBanda(6);
                necesidadesBanda.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al buscar por ID de banda: " + e.getMessage());
            }

            // TEST 3: Listar todas las necesidades
            System.out.println("\n>>> Test 3: LISTAR TODAS LAS NECESIDADES <<<");
            try {
                List<Necesidad> todas = necesidadRepository.findAll();
                todas.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al listar necesidades: " + e.getMessage());
            }

            System.out.println(" FIN DE TEST PARA NECESIDADES ");

            // TEST BANDA- EVENTO
            System.out.println("📋 TEST REPOSITORIO BANDA-EVENTO 📋");

            /*
             * Asumimos que ya existen registros válidos de Banda-Evento-Necesidad
             * ya que un objeto de banda-evento deben ser creados con registro existentes de
             * las clases
             * banda - evento - necesidad
             * 
             */
            int idBanda = 1;
            int idEvento = 1;
            int idNecesidad = 1;

            BandaEvento nuevaBandaEvento = new BandaEvento(idBanda, idEvento, idNecesidad);

            // TEST 1: Crear
            System.out.println("\n>>> Test 1: CREAR <<<");
            try {
                repo.create(nuevaBandaEvento);
                System.out.println("*.- BandaEvento creado: " + nuevaBandaEvento);
            } catch (Exception e) {
                System.err.println("Error al crear BandaEvento: " + e.getMessage());
            }

            // TEST 2: Buscar por ID
            System.out.println("\n>>> Test 2: BUSCAR POR ID <<<");
            try {
                BandaEvento be = repo.findById(idBanda, idEvento);
                System.out.println(be != null ? "*.- Encontrado: " + be : "*.- No se encontró la relación.");
            } catch (Exception e) {
                System.err.println("Error al buscar BandaEvento: " + e.getMessage());
            }

            // TEST 3: Actualizar (cambiar necesidad)
            System.out.println("\n>>> Test 3: ACTUALIZAR <<<");
            int nuevaNecesidad = 2; // Usar un ID válido de necesidad
            BandaEvento actualizado = new BandaEvento(idBanda, idEvento, nuevaNecesidad);
            try {
                int filas = repo.update(actualizado);
                System.out.println(filas == 1 ? "*.- Actualización OK: " + actualizado : "*.- No se pudo actualizar.");
            } catch (Exception e) {
                System.err.println("Error al actualizar: " + e.getMessage());
            }

            // TEST 4: Buscar todos
            System.out.println("\n>>> Test 4: LISTAR TODOS <<<");
            try {
                List<BandaEvento> lista = repo.findAll();
                lista.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al listar: " + e.getMessage());
            }

            // TEST 5: Buscar por ID de Banda
            System.out.println("\n>>> Test 5: BUSCAR POR ID DE BANDA <<<");
            try {
                List<BandaEvento> porBanda = repo.findByBanda(idBanda);
                porBanda.forEach(System.out::println);
            } catch (Exception e) {
                System.err.println("Error al buscar por banda: " + e.getMessage());
            }

            // TEST 6: Eliminar
            System.out.println("\n>>> Test 6: ELIMINAR Banda-Evento <<<");
            try {
                int filas = repo.delete(idBanda, idEvento);
                System.out.println(filas == 1 ? "*.- Banda-Evento eliminado correctamente." : "*.- No se pudo eliminar.");
            } catch (Exception e) {
                System.err.println("Error al eliminar: " + e.getMessage());
            }

            System.out.println(" FIN DE TEST BANDAEVENTO ");
        }
    }
}
