package ar.org.centro8.java.curso.ProductoraMusical.enums;

public enum TipoLugar {
    Bar("Bar"),CentroCultural("Centro Cultural"),FestivalAireLibre("Festival AireLibre"),
    MicroEstadio("Micro estadio"),Teatro("Teatro"),ClubNocturno("Club Nocturno");
    
    private String label;

    TipoLugar(String label) {
        this.label = label;
    }
   public String getLabel() {
        return label;
    }

    public static TipoLugar fromLabel(String label) {
        label = label.replace("-", " ").trim(); 
        for (TipoLugar tl : values()) {
            if (tl.label.equalsIgnoreCase(label)) {
                return tl;
            }
        }
        throw new IllegalArgumentException("No enum constant for label: " + label);
    }

    
}
