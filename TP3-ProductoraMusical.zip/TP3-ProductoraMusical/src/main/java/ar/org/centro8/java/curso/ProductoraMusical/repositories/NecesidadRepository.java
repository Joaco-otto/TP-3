package ar.org.centro8.java.curso.ProductoraMusical.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Necesidad;
import ar.org.centro8.java.curso.ProductoraMusical.enums.TipoLugar;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_NecesidadRepository;

@Repository

public class NecesidadRepository implements I_NecesidadRepository{

private final DataSource dataSource;
        
     private static final String SQL_CREATE = 
    "INSERT INTO necesidades (id_banda , tipo_lugar, descripcion) values (?,?,?)";

    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM necesidades WHERE id_necesidad=?";

    private static final String SQL_FIND_ALL =
        "SELECT * FROM necesidades";

    private static final String SQL_UPDATE = 
        "UPDATE necesidades SET id_banda=? , tipo_lugar=?, descripcion=? WHERE id_necesidad=?";

    private static final String SQL_DELETE = 
    
    "DELETE FROM necesidades WHERE id_necesidad=?";

    private static final String SQL_FIND_BY_ID_BANDA =
    
    "SELECT * FROM necesidades WHERE id_banda=?";
     
    public NecesidadRepository(DataSource dataSource){
        this.dataSource = dataSource; 
    }

    @Override
    
    public void create(Necesidad necesidad) throws SQLException {
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, necesidad.getIdBanda());
            ps.setString(2, necesidad.getTipoLugar().getLabel());
            ps.setString(3, necesidad.getDescripcion());
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    necesidad.setIdNecesidad(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public Necesidad findById(int idNecesidad) throws SQLException {
       try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, idNecesidad);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;


    }

    @Override
    public List<Necesidad> findAll() throws SQLException {
     List<Necesidad> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
        
    }


    @Override
    public int update(Necesidad necesidad) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setInt(1, necesidad.getIdBanda());
            ps.setString(2, necesidad.getTipoLugar().getLabel());
            ps.setString(3, necesidad.getDescripcion());
            ps.setInt(4, necesidad.getIdNecesidad());
            return ps.executeUpdate();
        }

    }

    @Override
    public int delete(int idNecesidad) throws SQLException {
         try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, idNecesidad);
            return ps.executeUpdate();
        }
    }

    @Override
    public List<Necesidad> findByIdBanda(int idBanda) throws SQLException {
         List<Necesidad> list = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_BANDA)) {
            ps.setInt(1, idBanda);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }
private Necesidad mapRow(ResultSet rs)throws SQLException {
        return new Necesidad(
            rs.getInt("id_necesidad"),
            rs.getInt("id_banda"),
            TipoLugar.fromLabel(rs.getString("tipo_lugar")),
            rs.getString("descripcion")
        );
    }

}
