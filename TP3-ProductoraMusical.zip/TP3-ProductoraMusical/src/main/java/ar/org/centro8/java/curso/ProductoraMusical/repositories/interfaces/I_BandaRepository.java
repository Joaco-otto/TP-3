package ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Banda;
import ar.org.centro8.java.curso.ProductoraMusical.enums.Genero;

public interface I_BandaRepository {

    void create(Banda banda) throws SQLException;

    Banda findById(int idBanda) throws SQLException;

    List<Banda> findAll() throws SQLException;

    int update(Banda banda) throws SQLException;

    int delete(int idBanda) throws SQLException;

    List<Banda> findByGenero(Genero genero) throws SQLException;

    List<Banda> findByCantidadMusicos(int cantidadMusicos) throws SQLException;
}
