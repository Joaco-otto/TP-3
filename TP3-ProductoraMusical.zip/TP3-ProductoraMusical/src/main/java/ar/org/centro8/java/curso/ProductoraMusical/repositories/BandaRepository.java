package ar.org.centro8.java.curso.ProductoraMusical.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arraylist;
import java.util.List;

import javax.sql.DataSource;
import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Banda;
import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_BandaRepository;


@Repository

public class BandaRepository implements I_BandaRepository {
    
         private final DataSource dataSource;
        
     private static final String SQL_CREATE = 
         "INSERT INTO bandas ( nombre, genero, contacto, cantidad_musicos, observaciones) values (?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM bandas WHERE idBanda=?";

    private static final String SQL_FIND_ALL =
        "SELECT * FROM bandas";

    private static final String SQL_UPDATE = 
        "UPDATE bandas SET nombre=?, genero=?, contacto=?, cantidad_musicos=?, observaciones=? WHERE idBanda=?";

    private static final String SQL_DELETE = 
    
    "DELETE FROM bandas WHERE idBanda=?";

    private static final String SQL_FIND_BY_GENERO_ =
    
    "SELECT * FROM bandas WHERE idBanda=?";

    private static final String SQL_FIND_BY_CANTIDAD_MUSICOS =
    
    "SELECT * FROM bandas WHERE cantidad_Musicos=?";
     
    public BandaRepository(DataSource dataSource){
        this.dataSource = dataSource;
    }
    
    
    @Override
    public void create(Banda banda) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)){
                    ps.setString(1, banda.getNombre());      
                    ps.setString(2, banda.getGenero());
                    ps.setString(3, banda.getContacto());
                    ps.setInt(4, banda.getCantidadMusicos());
                    ps.setString(5, banda.getObservaciones());                    
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if(keys.next()){
                            banda.setIdBanda(keys.getInt(1));  
                        }
                    }
            }        
    }
    
    
    @Override
    public Banda findById(int idBanda) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findById'");
    }

    @Override
    public List<Banda> findAll() throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAll'");
    }

    @Override
    public int update(Banda banda) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public int delete(Banda idBanda) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'delete'");
    }

    @Override
    public List<Banda> findByGenero(String genero) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByGenero'");
    }

    @Override
    public List<Banda> findByCantidadMusicos(int cantidadMusicos) throws SQLException {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findByCantidadMusicos'");
    }
         
}