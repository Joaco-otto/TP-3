package ar.org.centro8.java.curso.ProductoraMusical.entities;

import ar.org.centro8.java.curso.ProductoraMusical.enums.TipoLugar;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Necesidad {

    private int idNecesidad;
    private int idBanda;
    private TipoLugar tipoLugar;
    private String descripcion;

    public Necesidad(int idBanda, TipoLugar tipoLugar, String descripcion) {
        this.idBanda = idBanda;
        this.tipoLugar = tipoLugar;
        this.descripcion = descripcion;
    }


}
