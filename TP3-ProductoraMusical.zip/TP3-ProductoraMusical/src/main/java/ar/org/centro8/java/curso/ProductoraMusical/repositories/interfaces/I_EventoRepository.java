package ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces;

import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Evento;

public interface I_EventoRepository {
     void create(Evento evento) throws SQLException;
    Evento findById(int idEvento) throws SQLException;
    List<Evento> findAll() throws SQLException;
    int update (Evento evento) throws SQLException;
    int delete(Evento evento) throws SQLException; 
    List<Evento> findByFecha(Date fecha) throws SQLException;
    List<Evento> findByNombre(String nombre) throws SQLException;


}
