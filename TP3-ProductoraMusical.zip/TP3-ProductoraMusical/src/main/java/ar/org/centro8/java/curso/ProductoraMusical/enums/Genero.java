package ar.org.centro8.java.curso.ProductoraMusical.enums;

public enum Genero {
    Rock("Rock"),
    RNB("R&B"),
    Metal("Metal"),
    Folcklore("Folcklore"),
    Clasica("Clasica"),
    HipHop("Hip-Hop"),
    Electronica("Electronica"),
    LatinoAmericano("Latinoamericano");

    private final String label;

    Genero(String label) {
        this.label = label;

    }
      public String getLabel() {
     return label;
    }

    public static Genero fromLabel(String label) {
        for (Genero g : values()) {
            if (g.label.equalsIgnoreCase(label)) {
                return g;
            }
        }
        throw new IllegalArgumentException("No enum constant for label: " + label);
    }


}
