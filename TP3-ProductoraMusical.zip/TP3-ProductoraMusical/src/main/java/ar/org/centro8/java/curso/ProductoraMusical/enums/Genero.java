package ar.org.centro8.java.curso.ProductoraMusical.enums;

public enum Genero {
    Rock,RNB,Metal,Folcklore,Clasica,Hip_Hop,Electronica,LatinoAmericano;

}
