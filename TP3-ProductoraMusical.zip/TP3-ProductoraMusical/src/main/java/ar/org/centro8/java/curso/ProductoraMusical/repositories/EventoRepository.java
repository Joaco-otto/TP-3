package ar.org.centro8.java.curso.ProductoraMusical.repositories;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.java.curso.ProductoraMusical.entities.Evento;

import ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces.I_EventoRepository;

@Repository
public class EventoRepository implements I_EventoRepository{

    private final DataSource dataSource;
        
     private static final String SQL_CREATE = 
    "INSERT INTO eventos ( nombre, fecha, horario, id_lugar, descripcion) values (?,?,?,?,?)";

    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM eventos WHERE id_Evento=?";

    private static final String SQL_FIND_ALL =
        "SELECT * FROM eventos";

    private static final String SQL_UPDATE = 
        "UPDATE eventos SET nombre=?, fecha=?, horario=?, id_lugar=?, descripcion=? WHERE id_Evento=?";

    private static final String SQL_DELETE = 
    
    "DELETE FROM eventos WHERE id_evento=?";

    private static final String SQL_FIND_BY_FECHA_ =
    
    "SELECT * FROM eventos WHERE fecha= ?";

    private static final String SQL_FIND_BY_NOMBRE =
    
    "SELECT * FROM eventos WHERE nombre=?";
     
    public EventoRepository(DataSource dataSource){
        this.dataSource = dataSource;

}

    @Override
    public void create(Evento evento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)){
                    ps.setString(1, evento.getNombre());      
                    ps.setDate(2, evento.getFecha());
                    ps.setTime(3, evento.getHorario());
                    ps.setInt(4, evento.getIdLugar());
                    ps.setString(5, evento.getDescripcion());                    
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if(keys.next()){
                            evento.setIdEvento(keys.getInt(1));  
                        }
                    }
            }        
        
    }

    @Override
    public int delete(Evento idEvento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)){
                    ps.setInt(1, idEvento.getIdEvento());
                    return ps.executeUpdate();
                     
                }

        
    }

    @Override
    public List<Evento> findAll() throws SQLException {
        List<Evento> lista = new ArrayList<>();
        try(Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL)) {
                    ResultSet rs = ps.executeQuery();
                    while (rs.next()) {
                        lista.add(mapRow(rs));
                    }            
        } 
        return lista; 
        
    }


    @Override
    public List<Evento> findByFecha(Date fecha) throws SQLException {
        
        List<Evento> bandas = new ArrayList<>();
    try (Connection conn = dataSource.getConnection();
         PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_FECHA_)) {

        ps.setDate(1, fecha);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                bandas.add(mapRow(rs));
        
            }
        }
    }
    return bandas;
    }
    

    @Override
    public Evento findById(int idEvento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
            PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)){
                 ps.setInt(1, idEvento);
                    try (ResultSet rs = ps.executeQuery()) {
                        if(rs.next()){
                            return mapRow(rs);
                        }                        
                    }            
            }
            return null;
    }

    @Override
    public List<Evento> findByNombre(String nombre) throws SQLException {       
    List<Evento> bandas = new ArrayList<>();
    try (Connection conn = dataSource.getConnection();
         PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_NOMBRE)) {

        ps.setString(1, nombre);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                bandas.add(mapRow(rs));
            }
        }
    }
    return bandas;

    }

    @Override
    public int update(Evento evento) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)){
            ps.setString(1, evento.getNombre());
            ps.setDate(2, evento.getFecha());
            ps.setTime(3, evento.getHorario());
            ps.setInt(4, evento.getIdLugar());
            ps.setString(5, evento.getDescripcion());
            ps.setInt(6, evento.getIdEvento());
            int filasAfectadas = ps.executeUpdate();
                    return filasAfectadas;

                }
    }
        private Evento mapRow(ResultSet rs) throws SQLException{
        Evento evento = new Evento();
        evento.setIdEvento(rs.getInt("id_Evento"));
        evento.setNombre(rs.getString("nombre"));
        evento.setFecha(rs.getDate("fecha"));
        evento.setHorario(rs.getTime("horario"));
        evento.setIdLugar(rs.getInt("id_lugar"));

     return evento;
         }
    }