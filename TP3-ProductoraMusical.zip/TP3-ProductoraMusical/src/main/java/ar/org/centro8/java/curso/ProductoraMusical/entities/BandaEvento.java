package ar.org.centro8.java.curso.ProductoraMusical.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BandaEvento {

    private int idBanda;
    private int idEvento;
    private int idNecesidad;

}
