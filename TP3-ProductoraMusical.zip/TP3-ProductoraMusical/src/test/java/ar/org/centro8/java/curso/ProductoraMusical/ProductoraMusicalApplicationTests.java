package ar.org.centro8.java.curso.ProductoraMusical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductoraMusicalApplicationTests {

	@Test
	void contextLoads() {
	}

}
