package ar.org.centro8.java.curso.ProductoraMusical.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Banda {

    private int idBanda;
    private String nombre;
    private String genero; // Se usa ¨String¨ porque JDBC no traduce enums
    private String contacto;
    private int cantidadMusicos;
    private String observaciones;

}
