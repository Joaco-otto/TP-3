package ar.org.centro8.java.curso.ProductoraMusical.repositories.interfaces;

import java.sql.SQLException;
import java.util.List;

import ar.org.centro8.java.curso.ProductoraMusical.entities.BandaEvento;

public interface I_BandaEventoRepository {

     void create (BandaEvento bandaevento) throws SQLException;
    BandaEvento findById(int idBanda,int idEvento,int idNecesidad) throws SQLException;
    List<BandaEvento> findAll() throws SQLException;
    int update (BandaEvento bandaevento) throws SQLException;
    int delete(int idBanda,int idEvento,int idNecesidad) throws SQLException; 
    
 

}
