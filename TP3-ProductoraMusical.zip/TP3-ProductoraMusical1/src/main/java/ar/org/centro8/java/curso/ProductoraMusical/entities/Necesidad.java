package ar.org.centro8.java.curso.ProductoraMusical.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Necesidad {

    private int idNecesidad;
    private int idBanda;
    private String tipoLugar;
    private String descripcion;

}
