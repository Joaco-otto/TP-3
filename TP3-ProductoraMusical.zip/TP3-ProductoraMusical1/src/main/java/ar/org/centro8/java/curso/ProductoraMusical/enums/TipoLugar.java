package ar.org.centro8.java.curso.ProductoraMusical.enums;

public enum TipoLugar {
    Bar, Centro_Cultural, Festival_AireLibre, Micro_Estadio,Teatro,Club_Nocturno;

}
