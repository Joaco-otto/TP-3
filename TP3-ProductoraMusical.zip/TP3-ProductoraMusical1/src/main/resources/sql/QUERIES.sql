
-- Queries de consulta 

-- 1 ver todas las bandas 

select * from bandas;

-- 2 listar los lugares tipo BAR ordenados por capacidad

select nombre_lugar, capacidad from lugares where tipo_lugar = 'Bar' order by capacidad desc;

-- 3 ver todos los  eventos y el lugar donde se realizan

select e.nombre,l.nombre_lugar, e.fecha, e.horario
from eventos e
join lugares l on e.id_lugar = l.id_lugar;

-- 4 mostrar bandas que tocan en cada evento

select e.nombre, b.nombre
from bandas_eventos be
join eventos e on be.id_evento = e.id_evento
join bandas b on be.id_banda = b.id_banda
order by e.nombre;

-- 5 ver las necesidades de la banda CICLO OTTO en diferentes tipo de lugares 

select tipo_lugar, descripcion
from necesidades
where id_banda in (select id_banda from bandas where nombre = 'Ciclo Otto');

-- 6 contar cuantos eventos hace cada tipo de lugar

select l.tipo_lugar, COUNT(e.id_evento) as cantidad_eventos
from eventos e
join lugares l on e.id_lugar = l.id_lugar
group by l.tipo_lugar;

-- 7 obtener la cantidad de musicos por banda en orden descendente

select nombre, cantidad_musicos
from bandas
order by cantidad_musicos desc;


-- 8 listar todas las bandas que tocan en eventos de tiopo "FESTIVAL-AIRE LIBRE"

select distinct b.nombre
from bandas_eventos be
join eventos e on be.id_evento = e.id_evento
join lugares l on e.id_lugar = l.id_lugar
join bandas b on be.id_banda = b.id_banda
where l.tipo_lugar = 'Festival-AireLibre';

-- 9 mostrar el detalle completo de un evento (nombre, lugar, bandas, necesidades técnicas)

select 
      e.nombre,
      l.nombre_lugar,
      b.nombre,
      n.descripcion
from eventos e
join lugares l on e.id_lugar = l.id_lugar
join bandas_eventos be on e.id_evento = be.id_evento
join bandas b on be.id_banda = b.id_banda
join necesidades n on be.id_necesidad = n.id_necesidad
where e.nombre = 'Metal Fest BsAs';

-- 10 listar bandas con observaciones que contengan la palabra "alternativo"

select nombre, observaciones
from bandas
where observaciones like '%alternativo%';

-- 11 mostrar los eventos que ocurren en el mes de julio 2025

select nombre, fecha
from eventos
where month(fecha) = 7 and year(fecha) = 2025;

-- 12 Todas las necesidades de todas las bandas en todos los eventos

SELECT 
    b.nombre,
    e.nombre,
    l.tipo_lugar,
    n.descripcion
FROM bandas_eventos be
JOIN bandas b ON be.id_banda = b.id_banda
JOIN eventos e ON be.id_evento = e.id_evento
JOIN lugares l ON e.id_lugar = l.id_lugar
JOIN necesidades n ON be.id_necesidad = n.id_necesidad
ORDER BY e.nombre, b.nombre;


