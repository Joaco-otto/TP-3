-- " DML "
-- Se crea 10 registros para las tablas: Bandas-Lugares-Eventos-Necesidades
INSERT INTO bandas (nombre, genero, contacto, cantidad_musicos, observaciones) VALUES
('Ciclo Otto', 'Rock', 'contacto@ciclootto.com.ar', 4, 'Hard-rock porteño con intervalos acusticos'),
('De bolsillo', 'Rock', 'contacto@debolsillo.com.ar', 3, 'Power trio '),
('Magra Metal', 'Metal', 'magra666@gmail.com.ar', 4, 'Trash Metal'),
('Sonido Estelar', 'Electronica', 'info@sonidoestelar.com', 2, 'DJ set y sintetizadores'),
('Dj-Biza', 'Electronica', 'djbiza@hotmail.com.com.ar', 1, 'Dj set y bailarinas'),
('La Murga Urbana', 'Folcklore', 'lamurgurbana@gmail.com', 10, 'Murga contemporánea'),
('En Clave Jazz', 'Clasica', 'enclavejazz@gmail.com', 5, 'Fusión de jazz y clásica'),
('Los Versados', 'Hip-Hop', 'versados@hiphop.com', 3, 'Freestyle y beats propios'),
('Ritmo y Calle', 'R&B', 'ritmoycalle@gmail.com', 4, 'R&B con letras sociales'),
('Tempestad Sonora', 'Metal', 'metaltempestad@gmail.com', 5, 'Metal progresivo de CABA'),
('Raza del Sur', 'LatinoAmericano', 'contacto@razadelsur.com.ar', 6, 'Sonidos andinos y urbanos'),
('Noctámbulos', 'Rock', 'noctambulosrock@gmail.com', 4, 'Rock alternativo'),
('Kantuta Andina ', 'LatinoAmericano', 'Kantuta@outlook.com.ar', 5, 'Musica andina '),
('Violentango', 'Folcklore', 'tango@gmail.com.', 5, 'Tango instrumental contemporaneo'),
('Carlos y Alejandra', 'LatinoAmericano', 'batchata@gmail.com', 2, 'Duo musical con dupla de bailarines'),
('Orquesta Sur', 'Clasica', 'orquestasur@gmail.com', 12, 'Orquesta de cámara contemporánea');
INSERT INTO lugares (nombre_lugar, contacto, direccion, tipo, capacidad, observaciones) VALUES
('La Tangente', 'info@latangente.com', 'Honduras 5317, Palermo', 'Bar', 300, 'Espacio íntimo para shows'),
('Niceto Club', 'booking@niceto.com', 'Niceto Vega 5510, Palermo', 'Club Nocturno', 1200, 'Clásico lugar de la noche porteña'),
('CC Recoleta', 'info@ccrecoleta.gob.ar', 'Junín 1930, Recoleta', 'Centro Cultural', 800, 'Espacio cultural estatal'),
('Teatro Vorterix', 'info@vorterix.com', 'Av. Lacroze 3455, Colegiales', 'Teatro', 1500, 'Shows en vivo y transmisiones'),
('Parque Centenario', 'eventos@buenosaires.gob.ar', 'Av. Díaz Vélez 4800, Caballito', 'Festival-AireLibre', 5000, 'Festival gratuito'),
('Ciudad Cultural Konex', 'konex@cckonex.org', 'Sarmiento 3131, Balvanera', 'Centro Cultural', 1000, 'Espacio multidisciplinario'),
('The Roxy Live', 'contacto@theroxy.com', 'Niceto Vega 5542, Palermo', 'Club Nocturno', 900, 'Conciertos y DJ sets'),
('Sala Siranush', 'info@siranush.com', 'Armenia 1353, Palermo', 'Teatro', 600, 'Teatro con excelente acústica'),
('El Emergente', 'contacto@elemergente.com', 'Gallo 333, Abasto', 'Bar', 200, 'Shows underground'),
('Club Cultural Matienzo', 'matienzo@ccm.com', 'Pringles 1249, Villa Crespo', 'Centro Cultural', 400, 'Arte independiente');
INSERT INTO eventos (nombre, fecha, horario, id_lugar, descripcion) VALUES
('Festival Indie Otoño', '2025-07-10', '20:00:00', 1, 'Indie y alternativo en La Tangente'),
('Noche Electrónica', '2025-07-12', '23:00:00', 2, 'DJ sets y performances'),
('Ciclo Folclórico', '2025-07-15', '18:00:00', 3, 'Folclore joven y tradicional'),
('Clásicos Contemporáneos', '2025-07-20', '21:00:00', 4, 'Obras de cámara modernas'),
('Hip-Hop Capital', '2025-07-22', '22:00:00', 2, 'Competencia y recitales de rap'),
('Metal Fest BsAs', '2025-07-25', '20:00:00', 5, 'Encuentro de metal y rock pesado'),
('Latinoamérica Viva', '2025-07-28', '17:00:00', 5, 'Música andina y popular'),
('Concierto en el Konex', '2025-08-01', '20:30:00', 6, 'Fusión de estilos en vivo'),
('Roxy Rock Night', '2025-08-03', '22:00:00', 7, 'Banda emergente + DJ'),
('Noches de Cámara', '2025-08-05', '19:30:00', 8, 'Orquesta Sur en vivo');
-- insert into de necesidades segun id_banda y tipo_lugar:
-- CICLO OTTO (id_banda = 1, Rock)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(1, 'Bar', 'Backline básico y luces frontales'),
(1, 'Centro Cultural', 'Conexión para visuales y monitores'),
(1, 'Festival-AireLibre', 'Escenario alto y sonido frontal'),
(1, 'Micro Estadio', 'Sonido profesional y pantallas LED'),
(1, 'Teatro', 'Retornos monitoreados y buena acústica'),
(1, 'Club Nocturno', 'Luces móviles y consola digital');

-- DE BOLSILLO (2, Rock)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(2, 'Bar', '3 micrófonos y retorno básico'),
(2, 'Centro Cultural', 'Pantalla para visuales y técnico de sonido'),
(2, 'Festival-AireLibre', 'Estructura resistente y energía eléctrica'),
(2, 'Micro Estadio', 'PA de alta potencia y backline completo'),
(2, 'Teatro', 'Iluminación cálida y sillas móviles'),
(2, 'Club Nocturno', 'Efectos de luces y micrófonos inalámbricos');

-- MAGRA METAL (3, Metal)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(3, 'Bar', 'Micros para batería doble bombo'),
(3, 'Centro Cultural', 'Pantallas con proyección visual'),
(3, 'Festival-AireLibre', 'Escenario resistente y retorno de piso'),
(3, 'Micro Estadio', 'Pirotecnia controlada y tarimas'),
(3, 'Teatro', 'Cortinas negras y acústica cerrada'),
(3, 'Club Nocturno', 'Luces agresivas y niebla');

-- SONIDO ESTELAR (4, Electrónica)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(4, 'Bar', 'Mesa DJ y luces psicodélicas'),
(4, 'Centro Cultural', 'Pantallas LED y sistema estéreo'),
(4, 'Festival-AireLibre', 'Pantalla gigante y subwoofers'),
(4, 'Micro Estadio', 'Visuales mapeadas y sincronización de luces'),
(4, 'Teatro', 'Sonido envolvente y proyección multimedia'),
(4, 'Club Nocturno', 'Cabina elevada y máquina de humo');

-- DJ BIZA (5, Electrónica)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(5, 'Bar', 'Reproductores CDJ y auriculares DJ'),
(5, 'Centro Cultural', 'DJ set preconfigurado y espacio libre'),
(5, 'Festival-AireLibre', 'Luces LED y refuerzo de bajos'),
(5, 'Micro Estadio', 'Visuales interactivas y pista amplia'),
(5, 'Teatro', 'Proyector y sonido en 5.1'),
(5, 'Club Nocturno', 'Cabina de DJ y conexión rápida');

-- LA MURGA URBANA (6, Folklore)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(6, 'Bar', 'Espacio reducido y micrófonos ambientales'),
(6, 'Centro Cultural', 'Micros de contacto y buena acústica'),
(6, 'Festival-AireLibre', 'Escenario grande y protección contra clima'),
(6, 'Micro Estadio', 'Coordinación con bailarines y sonido envolvente'),
(6, 'Teatro', 'Sillas móviles y retorno de escenario'),
(6, 'Club Nocturno', 'Iluminación teatral y pista libre');

-- EN CLAVE JAZZ (7, Clásica)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(7, 'Bar', 'Piano eléctrico y buena microfonía'),
(7, 'Centro Cultural', 'Acústica cuidada y luz tenue'),
(7, 'Festival-AireLibre', 'Toldo y retorno acústico'),
(7, 'Micro Estadio', 'Micros ambientales y sillas para músicos'),
(7, 'Teatro', 'Piano de cola y atriles'),
(7, 'Club Nocturno', 'Iluminación suave y buen monitoreo');

-- LOS VERSADOS (8, Hip-Hop)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(8, 'Bar', 'Base de beats y micrófonos inalámbricos'),
(8, 'Centro Cultural', 'Proyector y visuales urbanas'),
(8, 'Festival-AireLibre', 'Micros de largo alcance y DJ booth'),
(8, 'Micro Estadio', 'Pantallas y fuego frío'),
(8, 'Teatro', 'Escenografía urbana y efectos visuales'),
(8, 'Club Nocturno', 'Luces RGB y micrófonos de mano');

-- RITMO Y CALLE (9, R&B)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(9, 'Bar', 'Monitores pequeños y buen retorno'),
(9, 'Centro Cultural', 'Piano eléctrico y micrófonos condensadores'),
(9, 'Festival-AireLibre', 'Retorno potente y pista despejada'),
(9, 'Micro Estadio', 'Proyecciones y sonido envolvente'),
(9, 'Teatro', 'Acústica dulce y efectos de luces'),
(9, 'Club Nocturno', 'DJ booth y luces suaves');

-- TEMPESTAD SONORA (10, Metal)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(10, 'Bar', 'Micros para batería doble pedal'),
(10, 'Centro Cultural', 'Luces oscuras y visuales'),
(10, 'Festival-AireLibre', 'Escenario alto y retornos potentes'),
(10, 'Micro Estadio', 'Estructura reforzada y técnicos extra'),
(10, 'Teatro', 'Sonido cerrado y escenografía básica'),
(10, 'Club Nocturno', 'Humo y luces robóticas');

-- RAZA DEL SUR (11, LatinoAmericano)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(11, 'Bar', 'Microfonía básica y bancos de madera'),
(11, 'Centro Cultural', 'Instrumentos tradicionales y decoración andina'),
(11, 'Festival-AireLibre', 'Carpa y sonido amplio'),
(11, 'Micro Estadio', 'Sonido potente y visuales naturales'),
(11, 'Teatro', 'Micros ambientales y fondos culturales'),
(11, 'Club Nocturno', 'Iluminación cálida y sillas móviles');

-- NOCTÁMBULOS (12, Rock)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(12, 'Bar', 'Conexión rápida y retorno simple'),
(12, 'Centro Cultural', 'Backline compartido y micrófonos de voz'),
(12, 'Festival-AireLibre', 'Escenario techado y luces frontales'),
(12, 'Micro Estadio', 'Tarima para batería y pantallas'),
(12, 'Teatro', 'Iluminación suave y retorno frontal'),
(12, 'Club Nocturno', 'Sonido fuerte y efectos visuales');

-- KANTUTA ANDINA (13, LatinoAmericano)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(13, 'Bar', 'Micros para charango y bombo'),
(13, 'Centro Cultural', 'Sillas, atriles y escenografía andina'),
(13, 'Festival-AireLibre', 'Escenario techado y retorno ambiental'),
(13, 'Micro Estadio', 'Pantalla con visuales naturales'),
(13, 'Teatro', 'Iluminación tradicional y retorno escénico'),
(13, 'Club Nocturno', 'Decoración temática y buena acústica');

-- VIOLENTANGO (14, Folklore)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(14, 'Bar', 'Piso firme para danza y buena acústica'),
(14, 'Centro Cultural', 'Proyector y tango visual'),
(14, 'Festival-AireLibre', 'Pista de baile segura y luz tenue'),
(14, 'Micro Estadio', 'Iluminación de gala y retorno central'),
(14, 'Teatro', 'Piso de madera y fondo oscuro'),
(14, 'Club Nocturno', 'Sonido cálido y espacio para bailarines');

-- CARLOS Y ALEJANDRA (15, LatinoAmericano)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(15, 'Bar', 'Pista reducida y luces románticas'),
(15, 'Centro Cultural', 'Sonido envolvente y piso especial'),
(15, 'Festival-AireLibre', 'Espacio para danza y micrófonos ambientales'),
(15, 'Micro Estadio', 'Iluminación escénica y pantalla de fondo'),
(15, 'Teatro', 'Luces cálidas y buen retorno'),
(15, 'Club Nocturno', 'Efectos visuales y espacio de coreografía');

-- ORQUESTA SUR (16, Clásica)
INSERT INTO necesidades (id_banda, tipo_lugar, descripcion) VALUES
(16, 'Bar', 'Atriles, piano eléctrico y buena acústica'),
(16, 'Centro Cultural', 'Escenario amplio y monitores'),
(16, 'Festival-AireLibre', 'Micros ambientales y buena visualización'),
(16, 'Micro Estadio', 'Distribución de secciones y sonido envolvente'),
(16, 'Teatro', 'Acústica profesional y luces suaves'),
(16, 'Club Nocturno', 'Espacio adaptado y reducción de ruido');
-- Inserts para la tabla bandas_eventos.
INSERT INTO bandas_eventos (id_banda, id_evento, id_necesidad) VALUES
-- Evento 1 (Bar): Ciclo Otto
(1, 1, (SELECT id_necesidad FROM necesidades WHERE id_banda = 1 AND tipo_lugar = 'Bar')),
-- Evento 1 (Bar): Magra Metal
(3, 1, (SELECT id_necesidad FROM necesidades WHERE id_banda = 3 AND tipo_lugar = 'Bar')),

-- Evento 2 (Club Nocturno): Sonido Estelar
(4, 2, (SELECT id_necesidad FROM necesidades WHERE id_banda = 4 AND tipo_lugar = 'Club Nocturno')),
-- Evento 2 (Club Nocturno): Dj-Biza
(5, 2, (SELECT id_necesidad FROM necesidades WHERE id_banda = 5 AND tipo_lugar = 'Club Nocturno')),

-- Evento 3 (Centro Cultural): La Murga Urbana
(6, 3, (SELECT id_necesidad FROM necesidades WHERE id_banda = 6 AND tipo_lugar = 'Centro Cultural')),
-- Evento 3 (Centro Cultural): En Clave Jazz
(7, 3, (SELECT id_necesidad FROM necesidades WHERE id_banda = 7 AND tipo_lugar = 'Centro Cultural')),

-- Evento 4 (Teatro): Orquesta Sur
(16, 4, (SELECT id_necesidad FROM necesidades WHERE id_banda = 16 AND tipo_lugar = 'Teatro')),
-- Evento 4 (Teatro): Violentango
(14, 4, (SELECT id_necesidad FROM necesidades WHERE id_banda = 14 AND tipo_lugar = 'Teatro')),

-- Evento 5 (Club Nocturno): Los Versados
(8, 5, (SELECT id_necesidad FROM necesidades WHERE id_banda = 8 AND tipo_lugar = 'Club Nocturno')),
-- Evento 5 (Club Nocturno): Tempestad Sonora
(10, 5, (SELECT id_necesidad FROM necesidades WHERE id_banda = 10 AND tipo_lugar = 'Club Nocturno')),

-- Evento 6 (Festival-AireLibre): Raza del Sur
(11, 6, (SELECT id_necesidad FROM necesidades WHERE id_banda = 11 AND tipo_lugar = 'Festival-AireLibre')),
-- Evento 6 (Festival-AireLibre): Kantuta Andina
(13, 6, (SELECT id_necesidad FROM necesidades WHERE id_banda = 13 AND tipo_lugar = 'Festival-AireLibre')),

-- Evento 7 (Festival-AireLibre): Magra Metal
(3, 7, (SELECT id_necesidad FROM necesidades WHERE id_banda = 3 AND tipo_lugar = 'Festival-AireLibre')),
-- Evento 7 (Festival-AireLibre): Ciclo Otto
(1, 7, (SELECT id_necesidad FROM necesidades WHERE id_banda = 1 AND tipo_lugar = 'Festival-AireLibre')),

-- Evento 8 (Centro Cultural): Carlos y Alejandra
(15, 8, (SELECT id_necesidad FROM necesidades WHERE id_banda = 15 AND tipo_lugar = 'Centro Cultural'));

