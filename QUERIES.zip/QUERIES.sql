
-- Queries de consulta 

-- ver todas las bandas 
select * from bandas;

-- listar los lugares tipo BAR ordenados por capacidad
select nombre_lugar, capacidad 
from lugares 
where tipo = 'Bar' 
order by capacidad desc;

-- ver todos los  eventos y el lugar donde se realizan
select e.nombre 
as evento, l.nombre_lugar 
as lugar, e.fecha, e.horario
from eventos e
join lugares l on e.id_lugar = l.id_lugar;

-- mostrar bandas que tocan en cada evento
select e.nombre as evento, 
       b.nombre as banda
from bandas_eventos be
join eventos e on be.id_evento = e.id_evento
join bandas b on be.id_banda = b.id_banda
order by e.nombre;

-- ver las necesidades de la banda CICLO OTTO en diferentes tipo de lugares 
select tipo_lugar,descripcion
from  necesidades
where id_banda = (
	 select id_banda 
     from bandas 
     where nombre = 'Ciclo Otto'
);

-- contar cuantos eventos hace cada tipo de lugar
select l.tipo, COUNT(e.id_evento) as cantidad_eventos
from eventos e
join lugares l on e.id_lugar = l.id_lugar
group by l.tipo;

-- obtener la cantidad de musicos por banda en orden descendente
select nombre, cantidad_musicos
from bandas
order by cantidad_musicos desc;

-- listar todas las bandas que tocan en eventos de tiopo "FESTIVAL-AIRE LIBRE"
select distinct b.nombre
from bandas_eventos be
join eventos e on be.id_evento = e.id_evento
join lugares l on e.id_lugar = l.id_lugar
join bandas b on be.id_banda = b.id_banda
where l.tipo = 'Festival-AireLibre';

-- mostrar el detalle completo de un evento (nombre, lugar, bandas, necesidades técnicas)
select  e.nombre as evento,
        l.nombre_lugar as lugar,
        b.nombre as banda,
        n.descripcion as necesidad
from eventos e
join lugares l on e.id_lugar = l.id_lugar
join bandas_eventos be on e.id_evento = be.id_evento
join bandas b on be.id_banda = b.id_banda
join necesidades n on be.id_necesidad = n.id_necesidad
where e.nombre = 'Metal Fest BsAs';

-- listar bandas con observaciones que contengan la palabra "alternativo"
select nombre, observaciones
from bandas
where observaciones like '%alternativo%';

-- mostrar los eventos que ocurren en el mes de julio 2025
select nombre, fecha
from eventos
where month(fecha) = 7 and year(fecha) = 2025;

-- Todas las necesidades de todas las bandas en todos los eventos
select 
    b.nombre as nombre_banda,
    e.nombre as nombre_evento,
    l.tipo as tipo_lugar,
    n.descripcion as necesidad
from bandas_eventos be
join bandas b on be.id_banda = b.id_banda
join eventos e on be.id_evento = e.id_evento
join lugares l on e.id_lugar = l.id_lugar
join necesidades n on be.id_necesidad = n.id_necesidad
order by e.nombre, b.nombre;